function toggleMenu() {
    let toggle = document.querySelector('.toggle');
    let navigation = document.querySelector('.navigation');
    let main = document.querySelector('.main');
    toggle.classList.toggle('active')
    navigation.classList.toggle('active')
    main.classList.toggle('active')
}
var cards = document.querySelectorAll('.card_single');
var table_box = document.querySelectorAll(".table_box");
var count = 0;
console.log(table_box.length)
table_box.forEach(function(a){
    a.classList.add('table'+count);
    count++;
});


document.querySelector("#box0").addEventListener("click",function(){
    document.querySelector("#box0").classList.toggle("active");
});
document.querySelector("#box1").addEventListener("click",function(){
    document.querySelector("#box1").classList.toggle("active");
});
document.querySelector("#box2").addEventListener("click",function(){
    document.querySelector("#box2").classList.toggle("active");
});
document.querySelector("#box3").addEventListener("click",function(){
    document.querySelector("#box3").classList.toggle("active");
});
document.querySelector("#box4").addEventListener("click",function(){
    document.querySelector("#box4").classList.toggle("active");
});
document.querySelector("#box5").addEventListener("click",function(){
    document.querySelector("#box5").classList.toggle("active");
});


var darkMode = document.querySelector('#darkMode');
darkMode.addEventListener('click',function(){
    if(this.classList.contains('fa-moon-o')){
        this.classList.remove('fa-moon-o')
        this.classList.add('fa-sun-o')
        document.querySelector('.navigation').style.background="#212121";
        document.querySelector('.navigation').style.color="#fff";
        document.querySelector('.main').style.background="linear-gradient(to bottom left, #413e3e 0%, #2e2e2e 100%)";
        document.querySelector('.topbar').style.background="linear-gradient(to bottom left, #262626 0%, #1c1c1c 100%)";
        document.querySelectorAll('.card_single').forEach(element => {
            element.style.background="#424242";
        });
        document.getElementsByTagName('footer')[0].style.background="linear-gradient(to bottom left, #413e3e 0%, #2e2e2e 100%)";
        document.querySelectorAll('.price').forEach(element2 => {
            element2.style.color='#FF8C00';
        });
    }else{
        this.classList.add('fa-moon-o')
        this.classList.remove('fa-sun-o')
        document.querySelector('.navigation').style.background="linear-gradient(135deg ,rgba(255.0, 140.0, 0.0, 1.0),rgba(174,218,132,1))";
        document.querySelector('.topbar').style.background="#FF8C00";
        document.querySelectorAll('.card_single').forEach(element => {
            element.style.background="linear-gradient(135deg ,rgba(255.0, 140.0, 0.0, 1.0),rgba(174,218,132,1))";
        });
        document.querySelector('.main').style.background="#fff";
        document.getElementsByTagName('footer')[0].style.background="linear-gradient(to bottom ,rgba(255.0, 140.0, 0.0, 1.0),rgba(174,218,132,1))";
        document.querySelectorAll('.price').forEach(element2 => {
            element2.style.color='#a5d17b';
        });
    }
});
